************
 README
************

TITLE: ドラえもんソリッド by モノドロンさん
SOURCE: http://asame.web.infoseek.co.jp/mgearf2.html
